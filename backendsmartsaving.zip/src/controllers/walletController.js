import WalletTransaction from "../models/WalletTransaction.js";
import apiResponse from "../utils/apiResponse.js";

// Get user wallet balance + transactions
export const getWalletDetails = async (req, res) => {
  try {
    const transactions = await WalletTransaction.find({ user: req.user.id }).sort({ createdAt: -1 });

    return res.json(
      apiResponse({
        success: true,
        message: "Wallet details fetched",
        data: {
          balance: transactions.length > 0 ? transactions[0].balanceAfter : 0,
          transactions,
        },
      })
    );
  } catch (err) {
    console.error(err);
    return res.status(500).json(apiResponse({ success: false, message: "Failed to fetch wallet details" }));
  }
};
