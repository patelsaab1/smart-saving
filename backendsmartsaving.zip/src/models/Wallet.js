import mongoose from "mongoose";

const walletSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, unique: true },
    balance: { type: Number, default: 0, min: 0 },
    transactions: [
      {
        amount: { type: Number, required: true },
        type: { type: String, enum: ["CREDIT", "DEBIT"], required: true },
        action: { type: String, required: true },
        referenceId: { type: mongoose.Schema.Types.ObjectId, refPath: "transactions.referenceModel" },
        referenceModel: { type: String, enum: ["Payment", "Referral", "Withdrawal", null] },
        description: { type: String, required: true },
        createdAt: { type: Date, default: Date.now },
      }
    ]
  },
  { timestamps: true }
);

walletSchema.index({ user: 1 });

export default mongoose.model("Wallet", walletSchema);
