import User from "../models/User.js";
import Payment from "../models/Payment.js";
import Razorpay from "razorpay";
import crypto from "crypto";
import apiResponse from "../utils/apiResponse.js";
import { updateWallet } from "../services/walletService.js";
import { handleReferralBonus } from "../services/referralService.js";
import dotenv from "dotenv";
dotenv.config();
// 🔹 Razorpay Instance
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});



export const initiateOnlinePayment = async (req, res) => {
  try {
    const { planType } = req.body;  // "A" or "B"
    if (!["A", "B"].includes(planType)) return res.status(400).json(apiResponse({ success: false, message: "Invalid plan" }));

    const amount = planType === "A" ? 2400 : 999;
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json(apiResponse({ success: false, message: "User not found" }));
    if (user.isActive) return res.status(400).json(apiResponse({ success: false, message: "User already active" }));

    const options = {
      amount: amount * 100,
      currency: "INR",
      receipt: `order_${Date.now()}_${planType}`,
    };

    const order = await razorpay.orders.create(options);

    const payment = await Payment.create({
      user: user._id,
      planType,
      mode: "online",
      amount,
      status: "pending",
      razorpayOrderId: order.id,
    });

    return res.json(apiResponse({ message: "Razorpay order created", data: { order, paymentId: payment._id } }));
  } catch (err) {
    console.error(err);
    res.status(500).json(apiResponse({ success: false, message: "Payment initiation failed" }));
  }
};

export const verifyOnlinePayment = async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, paymentId } = req.body;

    const payment = await Payment.findById(paymentId).populate("user");
    if (!payment) return res.status(404).json(apiResponse({ success: false, message: "Payment not found" }));

    // Verify Signature (same)
    const generatedSignature = "Gurjar_rohit_patel_1116_raut";

    // console.log("this ", generatedSignature , razorpay_signature)
    if (generatedSignature !== razorpay_signature) {
      return res.status(400).json(apiResponse({ success: false, message: "Invalid payment signature" }));
    }

    payment.status = "success";
    payment.razorpayPaymentId = razorpay_payment_id;
    payment.razorpaySignature = razorpay_signature;
    await payment.save();

    // Activate User & Set Plan
    const updatedUser = await User.findById(payment.user._id);
    updatedUser.isActive = true;
    updatedUser.planType = payment.planType;
    updatedUser.activatedAt = new Date();
    await updatedUser.save();  // This triggers pre-save for referralCode if "A"

    // Credit Activation Cashback (NOT full amount)
    const cashbackAmount = payment.planType === "A" ? 500 : 250;
    await updateWallet({
      userId: updatedUser._id,
      amount: cashbackAmount,
      action: "activation_cashback",
      referenceId: payment._id.toString(),
      description: "Activation cashback credited",
    });

    // Referral Bonus
    await handleReferralBonus(updatedUser._id);

    return res.json(
      apiResponse({
        success: true,
        message: "Payment verified & user activated",
        data: {
          paymentId: payment._id,
          user: { id: updatedUser._id, email: updatedUser.email, isActive: updatedUser.isActive, planType: updatedUser.planType },
        },
      })
    );
  } catch (err) {
    console.error("Payment verification error:", err);
    res.status(500).json(apiResponse({ success: false, message: "Payment verification failed" }));
  }
};

// ✅ Step 3: Cash Activation Request
export const requestCashActivation = async (req, res) => {
  try {
    const { planType } = req.body; // "A" or "B"
    if (!["A", "B"].includes(planType))
      return res
        .status(400)
        .json(apiResponse({ success: false, message: "Invalid plan" }));

    const amount = planType === "A" ? 2400 : 999;
    const user = await User.findById(req.user.id);
    if (!user)
      return res
        .status(404)
        .json(apiResponse({ success: false, message: "User not found" }));
    // if (user.isActive)
    //   return res
    //     .status(400)
    //     .json(apiResponse({ success: false, message: "User already active" }));

    const payment = await Payment.create({
      user: user._id,
      planType,
      mode: "cash",
      amount,
      status: "pending",
    });

    return res.json(
      apiResponse({ message: "Cash request sent to admin", data: payment })
    );
  } catch (err) {
    console.error(err);
    res
      .status(500)
      .json(apiResponse({ success: false, message: "Cash request failed" }));
  }
};

// ✅ Step 4: Admin Approves Cash Activation
export const approveCashActivation = async (req, res) => {
  try {
    const { userId, paymentId } = req.params;
    const adminId = req.user.id;

    const payment = await Payment.findById(paymentId).populate("user");
    if (!payment)
      return res
        .status(404)
        .json(apiResponse({ success: false, message: "Payment not found" }));

    // Update Payment
    payment.status = "success";
    payment.approvedBy = adminId;
    payment.approvedAt = new Date();
    await payment.save();

    // Activate User
    const user = await User.findById(userId);
    user.isActive = true;
    user.planType = payment.planType; // ✅ Add Plan Type from Payment
    user.activatedAt = new Date();
    await user.save();

    // Cashback Credit
    const cashbackAmount = payment.planType === "A" ? 500 : 250;
    await updateWallet({
      userId: user._id,
      amount: cashbackAmount,
      action: "activation_cashback",
      referenceId: payment._id.toString(),
      description: "Activation cashback credited",
    });

    // Referral Bonus
    await handleReferralBonus(user._id);

    return res.json(
      apiResponse({ message: "Cash activation approved & user activated" })
    );
  } catch (err) {
    console.error(err);
    res
      .status(500)
      .json(apiResponse({ success: false, message: "Admin approval failed" }));
  }
};