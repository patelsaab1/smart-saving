// src/models/WalletTransaction.js
import mongoose from "mongoose";

const walletTransactionSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    amount: { type: Number, required: true }, // +ve credit, -ve debit
    type: { type: String, enum: ["CREDIT", "DEBIT"], required: true },

    action: {
      type: String,
      enum: [
        "activation_cashback",
        "shopping_cashback",
        "first_shopping_cashback",
        "referral_bonus",
        "pair_bonus",
        "redeem_points",
        "withdrawal",
      ],
      required: true,
    },

    referenceId: { type: mongoose.Schema.Types.ObjectId, refPath: "referenceModel" },
    referenceModel: { type: String, enum: ["ShoppingBill", "Withdrawal", "User", "Payment"] },

    description: String,
    status: { type: String, enum: ["pending", "completed", "failed"], default: "completed" },
  },
  { timestamps: true }
);

walletTransactionSchema.index({ user: 1, createdAt: -1 });

export default mongoose.model("WalletTransaction", walletTransactionSchema);
