import Wallet from "../models/Wallet.js";
import AuditLog from "../models/AuditLog.js";

export const updateWallet = async ({ userId, amount, action, referenceId, referenceModel = null, description }, options = {}) => {
  const session = options.session || null;

  const wallet = await Wallet.findOne({ user: userId }).session(session);
  if (!wallet) throw new Error("Wallet not found");

  const type = amount >= 0 ? "CREDIT" : "DEBIT";

  // Update balance
  wallet.balance += amount;
  wallet.transactions.push({
    amount,
    type,
    action,
    referenceId,
    referenceModel,
    description,
  });

  await wallet.save({ session });

  // Audit Log
  await AuditLog.create(
    {
      adminId: null,
      action: `wallet_${action}`,
      details: { userId, amount, referenceId, description },
      timestamp: new Date(),
    },
    { session }
  );

  return wallet;
};
