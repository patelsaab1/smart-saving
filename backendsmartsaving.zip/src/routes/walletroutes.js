import express from "express";
import {
  getWalletBalance,
  getWalletTransactions,
  redeemPoints,
  initiateWithdrawal,
  approveWithdrawal,
} from "../controllers/walletController.js";
import { authMiddleware, isAdmin } from "../middlewares/authMiddleware.js";
import { uploadSingle } from "../middlewares/multerMemory.js";

const router = express.Router();

// User Routes
router.get("/balance", authMiddleware, getWalletBalance);
router.get("/transactions", authMiddleware, getWalletTransactions);
router.post("/redeem-points", authMiddleware, redeemPoints);
router.post("/withdraw", authMiddleware, initiateWithdrawal);

// Admin Routes
router.put("/withdraw/approve/:withdrawalId", authMiddleware, isAdmin, approveWithdrawal);

export default router;